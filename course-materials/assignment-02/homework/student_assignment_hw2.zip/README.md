# 第二次作业文件使用说明

先阅读 assignment.pdf，选择一个题目。

华为云资源待通知。账号注册、班级加入、代金券和环境配置的安排另行通知；现阶段可先在本地编写、调试代码，资源开放后完成昇腾训练。

提交时，将源码、运行说明、3–5 页 PDF 报告、训练结果和昇腾运行记录压缩为“学号+姓名+第二次作业.zip”，上传至 [第二次作业收集（WPS 群收文件）](https://yunbiz.wps.cn/c/collect/cWSzNeWL3qy)。截止时间为2026年11月5日（周四）23:59（北京时间）。

将学生源码包和 course_data.zip 解压到同一目录。数据文件如下，均已包含训练、验证、测试划分：

| 题目 | 文件 | 数量 |
|---|---|---:|
| 材料带隙 | datasets/processed/materials.json | 4604 |
| 分子水溶性 | datasets/processed/esol.json | 1128 |
| 新闻分类 | datasets/processed/news.json | 10000 |

新闻题另需 BERT 权重，目录为 models/chinese-bert-wwm-ext/，应包含 pytorch_model.bin、config.json、vocab.txt 等文件。数据来源和编码规则见 datasets/README.md。

使用学校的课程环境，或在独立虚拟环境安装 PyTorch 和 requirements.txt。三个模型框架分别位于 starter/materials/model.py、starter/esol/model.py 和 starter/news/model.py，训练入口为 starter/train.py。完成所选题的模型和训练代码即可。

可先用人工样例检查数据接口：

```text
python -m starter.train --task materials --fixture
python -m starter.train --task esol --fixture
python -m starter.train --task news --fixture
```

程序会打印输入形状，然后在待完成的 TODO 处停止。完成代码后，去掉 --fixture 即可读取真实数据。新闻题可用 --weights 指定 BERT 目录，昇腾运行时使用 --device npu。

coursekit/ 提供数据批处理、设备选择、指标计算和绘图工具。mask=True 表示真实元素或节点；分子图的 adj 已加自环并完成归一化。实验报告可参考 submission_template.md。
