# 《人工智能的原理与应用》第二次作业

以下三个题目任选其一，使用学校提供的华为昇腾资源完成实验，预计用时 6–12 小时。无需复现完整论文模型或追求最优性能。

## 华为云资源

华为云资源待通知，账号、入班、代金券和环境配置另行说明。现阶段可先在本地编写、调试代码，资源开放后完成昇腾训练。

## 作业要求

各题均须完成两组实验。核心模型和训练代码由本人编写，可使用 PyTorch 的基础层、自动微分和优化器，以及助教提供的数据读取和绘图工具。新闻题可用 Transformers 加载预训练 BERT。不得直接以完整开源项目作为作业成果，参考资料和借用代码应注明来源。

数据已划分好训练集、验证集和测试集，请勿重新划分。使用训练集更新模型，使用验证集选择参数和保存最佳模型，最后在测试集上评价。随机种子统一设为 2026。两组实验尽量采用相同的训练设置，并在报告中列出差异。

## 数据与代码

作业源码包和 course_data.zip 解压到同一目录后，数据位于 datasets/processed/：

题目一：materials.json，4604 条，训练/验证/测试为 3683/460/461。题目二：esol.json，1128 条，划分为 902/112/114。题目三：news.json，10000 篇，划分为 8000/1000/1000。

JSON 文件包含 records（样本）和 splits（划分索引），读取方法见 coursekit/data.py。模型和训练入口在 starter/，请完成 TODO。新闻题 BERT 权重另行提供，放入 models/chinese-bert-wwm-ext/。

## 实验报告与提交

1. Python 源码和运行说明，写明依赖版本、数据路径及训练、评测命令。
2. 3–5 页 PDF 报告，按五部分撰写：实验内容；实验数据及处理；关键代码（模型结构部分，可截取或粘贴）；训练过程（loss 曲线及分析）；实验结果（两组指标、预测结果图及分析）。报告中注明实验设置和参考文献。
3. 两组训练日志、结果图、测试集预测和最佳模型。大文件可提供校内下载位置，无需重复提交 BERT 预训练权重。
4. 昇腾运行记录，包括设备信息、PyTorch/torch_npu/CANN 版本、运行命令、日志和必要截图。

截止时间：2026年11月5日（周四）23:59（北京时间）
压缩包名称：学号+姓名+第二次作业.zip
提交入口：WPS 群收文件“第二次作业收集”

https://yunbiz.wps.cn/c/collect/cWSzNeWL3qy

## 评分

自主代码实现 40 分，模型运行及训练 20 分，对比实验与分析 25 分，报告及可复现性 15 分。

模型效果没有提升不影响对比得分，重点是实验和分析是否合理。遇到环境问题，请提供命令、版本和完整报错。

<!-- PAGEBREAK -->
# 题目一：基于注意力机制的材料带隙预测

根据材料的化学组成预测实验带隙，单位为 eV。数据使用 Matbench 的 matbench_expt_gap，共 4604 条。化学式已由助教解析，无需自行处理复杂化学式。

## 数据格式

读取 datasets/processed/materials.json。每条记录包含元素编号 z、原子比例 fractions、带隙 y 和样本 ID。元素编号为原子序数 1–118，0 用于填充。元素按原子序数排列，原子比例之和为 1。

例如 SiO2 对应 z=[8,14]、fractions=[2/3,1/3]。相同组成的记录放在同一集合中。这里采用课程固定划分，与 Matbench 官方交叉验证划分不同。

## 实验内容

1. 将元素编号和原子比例编码为模型输入。可使用元素嵌入，并为原子比例设计简单的数值编码。
2. 编写不使用 Attention 的回归模型：对元素表示进行汇聚，再用 MLP 输出带隙。
3. 在此基础上加入简化的自注意力，完成 Q、K、V 投影、缩放点积、Softmax 和汇聚。不要求实现完整 CrabNet。
4. 分别训练两种模型，使用验证集选择最佳模型，计算测试集 MAE 和 RMSE。

填充位置不应影响预测：计算注意力权重前应屏蔽无效 key，汇聚时应排除填充位置。可通过改变元素顺序、增加填充长度检查实现是否正确。

建议隐藏维度 32–64，batch size 32，AdamW 学习率 1e-3，训练 50–100 个 epoch。先用少量样本检查前向、反向传播，再开始完整训练。可以标准化带隙标签，但均值和标准差只能从训练集计算，评价前须还原为 eV。

## 报告内容

列出两种模型的结构、参数量、训练设置和测试集 MAE、RMSE。给出训练与验证损失曲线、真实值与预测值散点图，并在散点图中画出 y=x 参考线。

结合结果讨论：Attention 是否带来改善，哪些样本误差较大，组成比例和填充位置是怎样处理的。如果 Attention 没有改善，请根据曲线和预测结果分析原因。

## 参考资料

数据：https://matbench.materialsproject.org/

Wang et al. Compositionally restricted attention-based network for materials property predictions. npj Computational Materials, 2021.

论文：https://www.nature.com/articles/s41524-021-00545-1

<!-- PAGEBREAK -->
# 题目二：基于图神经网络的分子水溶性预测

根据分子图预测水溶性。数据使用 MoleculeNet ESOL，共 1128 个分子。标签为测量的 log10(mol/L)，误差也在这一对数尺度上计算。

## 数据格式

读取 datasets/processed/esol.json。助教已用 RDKit 将 SMILES 转换为分子图，每条记录包含节点特征 x、边索引 edge_index、标签 y 和样本 ID。学生无需编写 RDKit 转换程序。

节点为原子，特征共 6 维，依次为：原子序数/100、度数/4、形式电荷/4、芳香性、总氢数/4、原子质量/100。化学键存为双向边，文件中不含自环。本题不使用键型和手性特征；划分时将忽略立体异构后相同的分子放在同一集合中。

coursekit/data.py 中的 graph_batch 返回 x[B,N,6]、adj[B,N,N] 和 mask[B,N]。adj 已对真实节点添加自环，并作对称度归一化；填充区域为 0。mask=True 表示真实节点。模型中无需再次添加自环。

## 实验内容

1. 编写包含图卷积、激活函数、图级池化和回归层的 GNN，每个分子输出一个预测值。
2. 分别使用一层和两层图卷积，保持隐藏维度、训练设置等条件一致，比较预测效果。
3. 编写训练、验证和测试流程，使用验证集选择模型，计算测试集 MAE 和 RMSE。

可直接使用 PyTorch 基础算子实现图卷积，例如 H'=ReLU(adj H W+b)，再对真实节点进行平均池化。填充节点不能计入池化分母。请检查同一分子单独输入和与其他分子组成批次时，预测是否一致。

本题不要求安装 PyTorch Geometric。建议隐藏维度 32–64，batch size 16–32，学习率 1e-3，训练 50–100 个 epoch。若标准化标签，应只使用训练集统计量，并在计算指标前还原。

## 报告内容

列出一层和两层 GNN 的测试集 MAE、RMSE，给出训练与验证损失曲线以及预测散点图。说明图卷积和池化的实现方式，分析增加层数后的变化。

本题使用按规范 SMILES 分组的随机划分，不是分子骨架划分。讨论泛化能力时应说明这一点。原始 CSV 中的预测溶解度和其他描述符不作为输入。

## 参考资料

数据：https://deepchem.readthedocs.io/en/latest/api_reference/moleculenet.html

Delaney. ESOL: Estimating Aqueous Solubility Directly from Molecular Structure. J. Chem. Inf. Comput. Sci., 2004. DOI: 10.1021/ci034243x。

<!-- PAGEBREAK -->
# 题目三：基于预训练 Transformer 的中文新闻分类

使用中文预训练 BERT，将新闻分为科技、体育、财经、教育和娱乐五类。数据取自 THUCNews 原始新闻正文，每类 2000 篇，共 10000 篇。

## 数据与预训练模型

读取 datasets/processed/news.json。标签顺序为 0=科技、1=体育、2=财经、3=教育、4=娱乐。每类训练集 1600 篇、验证集 200 篇、测试集 200 篇，划分前已进行文本去重。

使用 hfl/chinese-bert-wwm-ext 及其配套 tokenizer。完整权重放在 models/chinese-bert-wwm-ext/，可离线加载。输入使用新闻正文开头，max_length=128，按 tokenizer 的规则添加特殊 token、截断和填充。

## 实验内容

1. 使用 AutoModel 加载 BERT，自行编写分类头，输出 5 类 logits，使用交叉熵训练。可取最后一层的 CLS 表示，接 Dropout 和线性层。不允许直接用 AutoModelForSequenceClassification 完成整个模型。
2. 实验 A：冻结 BERT 的全部参数，只训练分类头。
3. 实验 B：仅解冻第 12 层 Transformer Encoder，同时训练分类头。embedding、前 11 层 Encoder 和 pooler 保持冻结。
4. 使用昇腾资源完成两组训练，比较测试结果和训练开销。

注意区分参数冻结和训练模式：requires_grad 控制梯度，train()/eval() 控制 Dropout 等层的行为。冻结的 BERT 层保持 eval 模式，实验 B 只将末层设为 train。不要对部分解冻的整个编码器使用 no_grad()，否则末层无法更新。

建议 batch size 8，训练 3–5 个 epoch。两组分类头均可用学习率 1e-3，解冻的编码层用 2e-5。显存或 NPU 内存不足时可减小 batch size，并在报告中记录实际设置。检查冻结参数是否保持不变，以及解冻层是否确实获得梯度。

## 报告内容

报告两组测试集 Accuracy、Macro-F1、训练与验证损失曲线以及五类混淆矩阵。Macro-F1 对固定五类求平均，缺失类的 F1 记为 0；混淆矩阵的行表示真实类别，列表示预测类别。

列出两组可训练参数量、耗时和内存占用，讨论部分解冻的效果及容易混淆的类别。说明正文截断可能带来的信息损失。

## 参考资料

数据：https://github.com/thunlp/THUCTC

模型：https://huggingface.co/hfl/chinese-bert-wwm-ext

Cui et al. Revisiting Pre-Trained Models for Chinese Natural Language Processing. Findings of EMNLP, 2020, pp. 657–668。数据引用见 datasets/README.md。
