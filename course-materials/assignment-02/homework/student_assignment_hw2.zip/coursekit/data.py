import hashlib
import json
from pathlib import Path

import torch

CLASSES = ["科技", "体育", "财经", "教育", "娱乐"]


def read_records(path, split):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    if obj.get("schema") != 1 or split not in ("train", "val", "test"):
        raise ValueError("Expected schema=1 and train/val/test")
    indices = obj["splits"][split]
    return [obj["records"][i] for i in indices]


def material_batch(rows):
    n = max(len(r["z"]) for r in rows)
    z = torch.zeros(len(rows), n, dtype=torch.long)
    f = torch.zeros(len(rows), n)
    for i, r in enumerate(rows):
        z[i, :len(r["z"])] = torch.tensor(r["z"])
        f[i, :len(r["z"])] = torch.tensor(r["fractions"])
    return {"z": z, "fractions": f, "mask": z.ne(0)}, torch.tensor([r["y"] for r in rows], dtype=torch.float32)


def graph_batch(rows):
    """Padded dense batches: no cross-graph edges, no torch_scatter/PyG.

    Ahat = D^-1/2 (A+I) D^-1/2 on real nodes; padding stays zero.
    Edge indices are bidirectional and contain no self loops on disk.
    """
    n = max(len(r["x"]) for r in rows)
    x = torch.zeros(len(rows), n, 6)
    a = torch.zeros(len(rows), n, n)
    mask = torch.zeros(len(rows), n, dtype=torch.bool)
    for k, r in enumerate(rows):
        m = len(r["x"])
        x[k, :m] = torch.tensor(r["x"])
        mask[k, :m] = True
        a[k, :m, :m] = torch.eye(m)
        for s, t in zip(*r["edge_index"]):
            a[k, s, t] = 1
    inv = a.sum(-1).clamp_min(1).rsqrt()
    a = inv.unsqueeze(-1) * a * inv.unsqueeze(-2)
    return {"x": x, "adj": a, "mask": mask}, torch.tensor([r["y"] for r in rows], dtype=torch.float32)


class NewsCollator:
    def __init__(self, tokenizer, max_length=128):
        self.tokenizer, self.max_length = tokenizer, max_length

    def __call__(self, rows):
        encoded = self.tokenizer([r["text"] for r in rows], padding="max_length", truncation=True,
                                 max_length=self.max_length, return_tensors="pt")
        return dict(encoded), torch.tensor([r["y"] for r in rows], dtype=torch.long)


def fixture(task):
    """Synthetic shape checks ONLY. Never represent these as downloaded data."""
    if task == "materials":
        return [{"id": str(i), "z": [8, 14] if i % 2 else [14],
                 "fractions": [2/3, 1/3] if i % 2 else [1.0], "y": float(i % 2)} for i in range(20)]
    if task == "esol":
        return [{"id": str(i), "x": [[.06, .25, 0., 0., 0., .25]] * (i % 3 + 1),
                 "edge_index": [[v for j in range(i % 3) for v in (j,j+1)],
                                [v for j in range(i % 3) for v in (j+1,j)]],
                 "y": float(i % 3)} for i in range(20)]
    return [{"id": str(i), "text": CLASSES[i % 5] + "新闻内容", "y": i % 5} for i in range(20)]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
