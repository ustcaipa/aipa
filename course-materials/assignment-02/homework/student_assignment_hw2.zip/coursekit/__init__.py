"""Student-safe data and reporting utilities; no model or training answers."""
