import importlib.util
import os
import platform
import random

import numpy as np
import torch


def seed_all(seed=2026):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device(name="auto"):
    if name == "auto":
        # Explicit --device npu is required on Ascend to avoid silent CPU fallback.
        name = "cuda" if torch.cuda.is_available() else "cpu"
    if name == "npu":
        import torch_npu  # noqa: F401; registers the npu backend
        if not torch.npu.is_available():
            raise RuntimeError("NPU requested but unavailable")
        return torch.device("npu:0")
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    return torch.device(name)


def environment(device):
    return {"python": platform.python_version(), "os": platform.platform(), "torch": str(torch.__version__),
            "device": str(device), "cuda_runtime": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "torch_npu_installed": importlib.util.find_spec("torch_npu") is not None,
            "npu_validated": str(device).startswith("npu"), "pid": os.getpid()}
