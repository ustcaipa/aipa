import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score


def metrics(y, pred, classification=False):
    y, pred = np.asarray(y), np.asarray(pred)
    if classification:
        return {"Accuracy": float(accuracy_score(y, pred)),
                "Macro-F1": float(f1_score(y, pred, labels=list(range(5)), average="macro", zero_division=0))}
    return {"MAE": float(np.abs(y-pred).mean()), "RMSE": float(np.sqrt(np.mean((y-pred)**2)))}


def save_plots(out, history, y, pred, classification=False):
    out = Path(out)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot([r["epoch"] for r in history], [r["train_loss"] for r in history], label="train")
    ax.plot([r["epoch"] for r in history], [r["val_loss"] for r in history], label="validation")
    ax.set(xlabel="Epoch", ylabel="Cross entropy" if classification else "MSE (standardized target)")
    ax.legend(); fig.tight_layout(); fig.savefig(out/"loss.png", dpi=160); plt.close(fig)
    fig, ax = plt.subplots(figsize=(5, 4))
    if classification:
        cm = confusion_matrix(y, pred, labels=list(range(5)))
        np.savetxt(out/"confusion_matrix.csv", cm, fmt="%d", delimiter=",")
        ax.imshow(cm, cmap="Blues")
        for i in range(5):
            for j in range(5):
                ax.text(j, i, str(cm[i, j]), ha="center", va="center")
        ax.set(xticks=range(5), yticks=range(5), xlabel="Predicted class ID", ylabel="True class ID")
        ax.set_xticklabels(["Technology","Sports","Finance","Education","Entertainment"],rotation=35,ha="right",fontsize=8)
        ax.set_yticklabels(["Technology","Sports","Finance","Education","Entertainment"],fontsize=8)
    else:
        ax.scatter(y, pred, s=12, alpha=.6)
        lo, hi = min(min(y), min(pred)), max(max(y), max(pred))
        ax.plot([lo, hi], [lo, hi], "k--")
        ax.set(xlabel="Measured target", ylabel="Predicted target")
    fig.tight_layout(); fig.savefig(out/("confusion_matrix.png" if classification else "scatter.png"), dpi=160); plt.close(fig)


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
