"""Student entry point: supplied data interface; students implement model + loop."""
import argparse
import importlib

import torch
from torch.utils.data import DataLoader

from coursekit.data import NewsCollator, fixture, graph_batch, material_batch, read_records
from coursekit.device import get_device, seed_all


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--task",required=True,choices=["materials","esol","news"])
    p.add_argument("--variant"); p.add_argument("--data"); p.add_argument("--fixture",action="store_true")
    p.add_argument("--weights",default="models/chinese-bert-wwm-ext"); p.add_argument("--device",default="cpu")
    args=p.parse_args(); seed_all(); device=get_device(args.device)
    variant=args.variant or {"materials":"attention","esol":"two","news":"frozen"}[args.task]
    rows=fixture(args.task) if args.fixture else read_records(args.data or f"datasets/processed/{args.task}.json","train")
    encoder=None
    if args.task=="news" and not args.fixture:
        from transformers import AutoModel, AutoTokenizer
        tokenizer=AutoTokenizer.from_pretrained(args.weights,local_files_only=True)
        encoder=AutoModel.from_pretrained(args.weights,local_files_only=True,attn_implementation="eager")
        collate=NewsCollator(tokenizer)
    elif args.task=="news":
        # Deliberately synthetic IDs; no downloaded weights needed to reach TODO.
        def collate(rows):
            ids=torch.tensor([[2,4+r["y"],3] for r in rows])
            return {"input_ids":ids,"attention_mask":torch.ones_like(ids)},torch.tensor([r["y"] for r in rows])
    else: collate=material_batch if args.task=="materials" else graph_batch
    loader=DataLoader(rows,batch_size=4,collate_fn=collate)
    x,y=next(iter(loader))
    print(f"Data interface OK; task={args.task}; device={device}; fixture={args.fixture}; shapes="
          f"{ {k:tuple(v.shape) for k,v in x.items()} }; target={tuple(y.shape)}",flush=True)
    cls=importlib.import_module(f"starter.{args.task}.model").StudentModel
    model=cls(encoder,variant) if args.task=="news" else cls(variant)
    model.to(device)
    # TODO T1: load separate validation/test sets, fit target scaling on TRAIN only.
    # TODO T2: optimizer, zero_grad, forward, loss, backward, step; validation each epoch.
    # TODO T3: select checkpoint by validation loss, evaluate test once after selection.
    # TODO T4: save config, seed, split hash, history, predictions, metrics, model and plots.
    # coursekit.reporting contains metric/plot helpers, but no training loop.
    raise NotImplementedError("TODO T1-T4: implement your own training and evaluation")


if __name__=="__main__": main()
