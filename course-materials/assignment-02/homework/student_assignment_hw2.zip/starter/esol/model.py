from torch import nn


class StudentModel(nn.Module):
    def __init__(self, variant="two"):
        super().__init__()
        self.variant=variant
        # TODO：定义一层或两层图卷积，以及回归层。
        raise NotImplementedError("TODO G1: implement graph model layers")

    def forward(self, x, adj, mask):
        # x: [B,N,6]，adj: [B,N,N]，mask=True 表示真实节点。
        # adj 已加自环并归一化。
        # TODO：图卷积后对真实节点池化，返回 [B]。
        raise NotImplementedError("TODO G2: graph convolution and graph-level pooling")
