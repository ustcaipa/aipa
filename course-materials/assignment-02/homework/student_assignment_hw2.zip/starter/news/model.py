from torch import nn


class StudentModel(nn.Module):
    def __init__(self, encoder, variant="frozen"):
        super().__init__()
        self.encoder, self.variant=encoder, variant
        # TODO：设置参数冻结范围，定义五分类的分类头。
        # variant=last 时只解冻 encoder.layer[-1]，pooler 保持冻结。
        raise NotImplementedError("TODO N1: freezing policy and custom classification head")

    def train(self, mode=True):
        # TODO：冻结层保持 eval，按 variant 设置末层的训练模式。
        return super().train(mode)

    def forward(self, **tokens):
        # TODO：取编码表示并分类，返回 [B,5]。
        # 部分解冻时，不能对整个 encoder 使用 no_grad()。
        raise NotImplementedError("TODO N2: encoder representation and classification")
