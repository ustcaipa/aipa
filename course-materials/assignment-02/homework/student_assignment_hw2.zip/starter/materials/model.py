from torch import nn


class StudentModel(nn.Module):
    def __init__(self, variant="attention"):
        super().__init__()
        self.variant=variant
        # TODO：定义元素嵌入、比例编码、注意力层和回归层。
        raise NotImplementedError("TODO M1: implement material model layers")

    def forward(self, z, fractions, mask):
        # z、fractions、mask 的形状均为 [B,L]，mask=True 表示真实元素。
        # TODO：完成注意力和汇聚，排除填充位置，返回 [B]。
        raise NotImplementedError("TODO M2: attention, masked pooling and regression")
