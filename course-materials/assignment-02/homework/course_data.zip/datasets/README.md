# 数据来源、固定划分与权利说明

所有命令从作业包根目录运行。原始文件位于 `datasets/raw/`，固定处理结果位于 `datasets/processed/`。JSON 的 `records` 保存样本；`splits` 保存训练、验证、测试的零起点索引。旁边的 `.manifest.json` 保存原始与处理文件 SHA-256、数量和划分信息。**发放后冻结并归档处理文件，学生不得重新随机划分。** 具体划分以 JSON 索引为准，不只依赖一个 seed。

## 材料

- 来源：[Matbench](https://matbench.materialsproject.org/)，`matbench_expt_gap`，4604 条、composition -> gap expt (eV)。
- 下载程序读取 [matminer 官方元数据](https://raw.githubusercontent.com/hackingmaterials/matminer/master/matminer/datasets/dataset_metadata.json) 中该任务的 URL 和 SHA-256，完整下载并核验，拒绝错哈希或错数量。首次成功后保留元数据和原始文件。
- 命令：`python -m prepare_data.materials`。需要 TA 环境的 pymatgen；学生只需 PyTorch 读取解析后的 JSON。
- `pymatgen.Composition` 解析括号、非整数化学计量；原子占比归一化、按原子序数排序；0=PAD，1..118=原子序数，映射另存 `datasets/elements.json`。
- 相同元素原子占比（10 位小数）作为一组。排序组键、seed=2026 打乱、按相对剩余容量分配到 80/10/10 目标集合；保留所有观测，组内标签不求平均，实际数量可略偏离。按组而非行划分防止相同输入泄漏。
- 这是课程 holdout，**不是官方 Matbench 五折**，不得宣称榜单复现。目标标准化只在模型训练时用训练集拟合。
- 引用：Dunn et al., *Matbench: A benchmarking toolkit for materials machine learning*, npj Computational Materials 6, 138 (2020), DOI [10.1038/s41524-020-00406-3](https://doi.org/10.1038/s41524-020-00406-3)；Zhuo et al., *Predicting the Band Gaps of Inorganic Solids by Machine Learning*, J. Phys. Chem. Lett. 9, 1668–1673 (2018), DOI [10.1021/acs.jpclett.8b00124](https://doi.org/10.1021/acs.jpclett.8b00124)。模型参考为 Wang et al., CrabNet (2021), DOI [10.1038/s41524-021-00545-1](https://doi.org/10.1038/s41524-021-00545-1)。

## ESOL

- 来源：[DeepChem 官方 loader](https://github.com/deepchem/deepchem/blob/master/deepchem/molnet/load_function/delaney_datasets.py) 指定的 [CSV](https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/delaney-processed.csv)，1128 条。
- 命令：`python -m prepare_data.esol`。只需 TA 安装 RDKit；无需安装 DeepChem、TensorFlow 或 PyG。
- **标签严格为 `measured log solubility in mols per litre`**，单位 log10(mol/L)。不使用 `ESOL predicted ...` 或 CSV 中其他描述符作为输入。
- 6 维原子特征依次为 Z/100、degree/4、formal_charge/4、aromatic、total_H/4、mass/100；RDKit 默认隐式 H，芳香性用默认 RDKit 规则。所有键视作无权双向边，不用键型，是有意的教学简化；无键单原子图也合法。
- 边索引格式 `[2,E]`，磁盘不加自环。`graph_batch` 将不同图放在不同 batch 维，真实节点加单位阵后计算 `D^-1/2 (A+I) D^-1/2`，PAD 邻接为 0。池化在模型中实现，不能包括 PAD。
- 按 RDKit canonical non-isomeric SMILES 分组后使用与材料相同的固定 80/10/10 分组随机算法。因本简化模型未编码手性，立体异构体也归入同组，防止相同可见结构跨集合。**不是骨架划分，不能用于声称新骨架外推性能**。保留所有观测。
- 引用：Delaney (2004), *ESOL: Estimating Aqueous Solubility Directly from Molecular Structure*, DOI [10.1021/ci034243x](https://doi.org/10.1021/ci034243x)；Wu et al., *MoleculeNet*, Chemical Science (2018), DOI [10.1039/C7SC02664A](https://doi.org/10.1039/C7SC02664A)。

## THUCNews 与 BERT

- 官方来源：[THUCTC/THUCNews](https://github.com/thunlp/THUCTC)。官方 README 指引到 `thuctc.thunlp.org` 填写信息获取原始语料；本次同时实测 [THUNLP 原始 ZIP 公开端点](https://thunlp.oss-cn-qingdao.aliyuncs.com/THUCNews.zip) 可访问，大小 1,560,309,796 bytes。脚本不自动填写身份信息，也不把第三方短标题数据冒充原始正文。
- 为减少下载，运行 `python -m prepare_data.fetch_news_subset`：读取原始 ZIP 中央目录，按 `SHA256('2026:'+archive_path)` 在每类全部成员中排序，确定性选取 2300 个候选正文（共 11500），并发 Range 下载并逐文件核对原 ZIP CRC32、长度、UTF-8，再保存 SHA-256 清单。这是候选预抽样，之后在候选全文间去重，再做每类 2000 的最终抽样与划分。没有下载全部 74 万篇，也不声称已对整个原始语料去重。`download_manifest.json` 记录实际取得的原始成员路径与摘要。
- 助教获取并解压后，应形成 `THUCNews/科技/*.txt` 等五个类别目录。命令：`python -m prepare_data.news --input PATH/THUCNews`。
- 标签固定 0 科技、1 体育、2 财经、3 教育、4 娱乐。全体候选先做 NFKC、去空白，以规范化前 512 字符的 SHA-256 去重；冲突类别组整组删除，短于 20 字符的内容跳过。此规则可减少同开头近重复，但无法保证消除所有新闻转载或语义近重复。
- 每类按 `SHA256('2026:'+group_hash)` 排序，选 2000 条，前 1600/随后 200/最后 200 分别为 train/val/test。总计 10000，8000/1000/1000。样本保存原始路径与全文摘要，方便审计。抽样不依赖目录遍历顺序或文件名类别以外的信息，不把路径输入模型。
- 默认 BERT 取正文开头，统一 max_length=128；标准 tokenizer 添加特殊 token 后截断、固定长度 PAD。可在平台试跑后由教师统一调整长度，不能每个对比组自行改变。
- 权重：`python -m prepare_data.weights`，从 [HFL 官方模型仓库](https://huggingface.co/hfl/chinese-bert-wwm-ext) 解析 commit SHA，完整下载权重和 tokenizer，并执行本地加载检查；清单记录 revision 与 SHA-256。只有配置文件或 HTTP 成功不算完整权重已可用。
- 引用：郭志芃等，*THUCTC：一个高效的中文文本分类工具包* (2016)；Cui et al., *Revisiting Pre-Trained Models for Chinese Natural Language Processing*, Findings of EMNLP 2020, [论文](https://aclanthology.org/2020.findings-emnlp.58/)。

## 许可证与发放边界

本作业原创代码采用根目录 `LICENSE` 的 MIT 许可；**该许可不覆盖第三方数据、预训练权重、论文或字体**。

Matbench/matminer 的代码许可与原始数据许可应区分；请保留下载条目的来源信息、上游条款及原始论文引用。ESOL 可从 DeepChem 下载，但 CSV 未单列明确的数据再分发许可，不能仅因 DeepChem 代码是 MIT 就把数据标为 MIT。THUCTC README 说明工具面向研究开放并对商业用途提出许可要求；该工具说明不能自动视为所有新浪新闻正文的自由再分发许可。THUCNews 数据获取与教学分发应遵守学校和数据方条款。

HFL 模型页标记 Apache-2.0；保留模型卡、许可、来源及修改说明。不要把权重纳入作业源码许可。许可依据与核对日期：2026-10-22，网页可能更新，正式发放前保留当次条款快照。

默认 `tools/package_student.py` **不打包原始/处理数据及权重**。助教应从有权限的课程平台另行发放处理数据，或让有权限的学生运行下载；只有明确完成数据授权核对后才使用 `--include-data` 把两个回归数据及已准备的新闻数据纳入发布包。含新闻正文的包仅发布到允许的校内范围。
