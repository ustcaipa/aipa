# 第三方来源与引用

本包原创教学代码适用根目录 MIT 许可。第三方内容保持自己的条款；公开可下载不等于可任意再分发。

| 内容 | 来源与条款依据 | 本包处理 |
|---|---|---|
| Matbench / matbench_expt_gap | https://matbench.materialsproject.org/ 及 matminer 官方数据元信息、原始带隙论文 | 下载时验证官方 SHA-256；固定课堂 holdout，不替代官方 CV；保留来源与引用 |
| ESOL 数据 | DeepChem 官方 loader 指定 CSV；Delaney (2004) 与 MoleculeNet (2018) | 只保留图和测量标签；不把 DeepChem 代码许可自动套用于原始数据 |
| THUCNews 新闻正文 | https://github.com/thunlp/THUCTC 及 THUNLP 原始 ZIP；原始新闻来自新浪 | 只下载确定性候选正文；保留文件路径、CRC、摘要，按校内课程授权范围发放 |
| HFL chinese-bert-wwm-ext | https://huggingface.co/hfl/chinese-bert-wwm-ext ，模型页标记 Apache-2.0 | 保留模型卡、固定 revision 和文件摘要；权重不混入 MIT 代码许可 |
| PyTorch / Transformers / RDKit / pymatgen 等 | 各依赖项目的上游许可 | 不捆绑其源码或二进制至学生源码包；本地环境独立安装 |
| PDF 中文字体 | 本机 Windows 宋体/黑体，嵌入本地生成的 PDF | 不另行分发原始字体文件；其他平台请使用具有适合嵌入条款的字体 |

数据原始论文、模型论文及引用格式见 datasets/README.md 和 assignment.pdf。第三方条款核对日期为 2026-10-22；课程实际上传前保留当次数据方条款与学校允许的发放范围。
